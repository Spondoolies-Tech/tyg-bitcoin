<?php return array(
/**
 * Theme configuration goes there
 */
    'name'    => 'Delirium',   					// theme name
    'styled'  => false,              			// true if current theme supports styling
    'scripts' => array("dropdown", "tabs")		// javascripts theme uses
);